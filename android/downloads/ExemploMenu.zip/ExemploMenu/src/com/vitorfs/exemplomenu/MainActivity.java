package com.vitorfs.exemplomenu;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends ListActivity {
	
	private String menu[] = { "Inicial", "Sobre", "Sair"};
	private String classes[] = { "InicialActivity", "SobreActivity", "SairActivity" };

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setListAdapter(new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, menu));
	}

	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		super.onListItemClick(l, v, position, id);
		try {
			Class c = Class.forName("com.vitorfs.exemplomenu." + classes[position]);
			Intent i = new Intent(MainActivity.this, c);
			startActivity(i);
		} catch (ClassNotFoundException e){
			e.printStackTrace();
		}
	}

}
