package com.vitorfs.conversorkm;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {

	private Button calcular;
	
	private static double MILES = 0.62137;
	
	private OnClickListener calculateClick = new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			TextView textView = (TextView) findViewById(R.id.mi_text);
			try {
				Double km;
				Double mi;
				EditText editText = (EditText) findViewById(R.id.km_txt);
				km = Double.parseDouble(editText.getText().toString());
				mi = km * MILES;			
				textView.setText("Resultado: " + mi.toString() + " milhas");
			} catch (Exception e) {
				textView.setText("Valor informado inválido!");
			}
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);	
		setContentView(R.layout.activity_main);
		
		calcular = (Button) findViewById(R.id.calc_button);
		calcular.setOnClickListener(calculateClick);
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
