/** Automatically generated file. DO NOT MODIFY */
package com.vitorfs.exemploasynctask;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}