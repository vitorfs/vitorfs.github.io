package com.vitorfs.exemploasynctask;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Html;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	public void postData(View view) {
		    
		class SendPostReqAsyncTask extends AsyncTask<String, Void, String> {
			
			private ProgressDialog dialog;
			
			public SendPostReqAsyncTask() {
				this.dialog = new ProgressDialog(MainActivity.this);
			}

			@Override
			protected String doInBackground(String... params) {
			    // Create a new HttpClient and Post Header
			    HttpClient httpclient = new DefaultHttpClient();
			    HttpPost httppost = new HttpPost("http://m.correios.com.br/movel/buscaCepConfirma.do");
			    
			    try {
			        // Add your data
			        List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(4);
			        nameValuePairs.add(new BasicNameValuePair("cepEntrada", params[0]));
			        nameValuePairs.add(new BasicNameValuePair("tipoCep", ""));
			        nameValuePairs.add(new BasicNameValuePair("cepTemp", ""));
			        nameValuePairs.add(new BasicNameValuePair("metodo", "buscarCep"));
			        httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));

			        // Execute HTTP Post Request
			        HttpResponse response = httpclient.execute(httppost);
			        InputStream inputStream = response.getEntity().getContent();
			        InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
			        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                    StringBuilder stringBuilder = new StringBuilder();
                    String bufferedStrChunk = null;
                    int i = 0;
                    while((bufferedStrChunk = bufferedReader.readLine()) != null){
                    	i++;
                        if (i >= 70 && i <= 85) {
                        	stringBuilder.append(bufferedStrChunk);
                        }
                    }
                    return stringBuilder.toString();

			    } catch (ClientProtocolException e) {
			        // TODO Auto-generated catch block
			    } catch (IOException e) {
			        // TODO Auto-generated catch block
			    }
				return null;
			}
			
			@Override
			protected void onPreExecute() {
				this.dialog.setMessage("Buscando CEP...");
				this.dialog.show();
			}
			
	        @Override
	        protected void onPostExecute(String result) {
	            super.onPostExecute(result);
	            
	            if (this.dialog.isShowing()) {
					this.dialog.dismiss();
				}
	            
	            TextView textView = (TextView) findViewById(R.id.retorno);
	            textView.setText(Html.fromHtml(result));
                //Toast.makeText(getApplicationContext(), result, Toast.LENGTH_LONG).show();
	        } 
		}
		
	    String cep;
	    EditText edit = (EditText) findViewById(R.id.cep);
	    cep = edit.getText().toString();
	    
		SendPostReqAsyncTask post = new SendPostReqAsyncTask();
		post.execute(cep);
	}

}
