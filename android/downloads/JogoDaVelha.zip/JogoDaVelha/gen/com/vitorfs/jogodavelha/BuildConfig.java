/** Automatically generated file. DO NOT MODIFY */
package com.vitorfs.jogodavelha;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}