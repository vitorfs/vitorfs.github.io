package com.vitorfs.jogodavelha;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
	
	private Game game;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		game = new Game();
		setContentView(R.layout.activity_main);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	public void play(View v) {
		if (!game.hasWon()) {
			if (game.doPlay(v.getId())) {
				Button btn = (Button) v;
				btn.setText(game.getPlayerCode());
				if (game.hasWon()) {
					TextView message = (TextView) findViewById(R.id.message);
					message.setText("Vencedor: " + game.getPlayerCode());
				}
				else {
					game.nextPlayer();
				}
			}
		}
	}
	
	public void newGame(View v) {
		game = new Game();
		((Button) findViewById(R.id.button_1_id)).setText("");
		((Button) findViewById(R.id.button_2_id)).setText("");
		((Button) findViewById(R.id.button_3_id)).setText("");
		((Button) findViewById(R.id.button_4_id)).setText("");
		((Button) findViewById(R.id.button_5_id)).setText("");
		((Button) findViewById(R.id.button_6_id)).setText("");
		((Button) findViewById(R.id.button_7_id)).setText("");
		((Button) findViewById(R.id.button_8_id)).setText("");
		((Button) findViewById(R.id.button_9_id)).setText("");
		
		TextView message = (TextView) findViewById(R.id.message);
		message.setText("");
	}

}
