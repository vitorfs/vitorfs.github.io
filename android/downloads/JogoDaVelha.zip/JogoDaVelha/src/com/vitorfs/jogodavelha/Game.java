package com.vitorfs.jogodavelha;

import android.graphics.Point;

public class Game {
	
	private int player;
	private Point point;
	private int[][] game;
	
	public Game() {
		player = 0;
		point = new Point();
		game = new int[3][3];
		
		for (int i = 0 ; i < 3 ; i++) {
			for (int j = 0 ; j < 3 ; j++) {
				game[i][j] = -1;
			}
		}
	}
	
	public String getPlayerCode() {
		String code = "X";
		if (player == 0) code = "O";
		return code;
	}
	
	public void nextPlayer() {
		player = (player + 1) % 2; 
	}
	
	public boolean doPlay(int id) {
		switch(id) {
		case R.id.button_1_id:
			point.set(0, 0);
			break;
		case R.id.button_2_id:
			point.set(0, 1);
			break;
		case R.id.button_3_id:
			point.set(0, 2);
			break;
		case R.id.button_4_id:
			point.set(1, 0);
			break;
		case R.id.button_5_id:
			point.set(1, 1);
			break;
		case R.id.button_6_id:
			point.set(1, 2);
			break;
		case R.id.button_7_id:
			point.set(2, 0);
			break;
		case R.id.button_8_id:
			point.set(2, 1);
			break;
		case R.id.button_9_id:
			point.set(2, 2);
			break;
		}
		
		if (game[point.x][point.y] == -1) {
			game[point.x][point.y] = player;
			return true;
		}
		return false;
	}
	
	public boolean hasWon() {
		return (game[point.x][0] == player
	             && game[point.x][1] == player
	             && game[point.x][2] == player
	        || game[0][point.y] == player
	             && game[1][point.y] == player
	             && game[2][point.y] == player
	        || point.x == point.y
	             && game[0][0] == player
	             && game[1][1] == player
	             && game[2][2] == player
	        || point.x + point.y == 2
	             && game[0][2] == player
	             && game[1][1] == player
	             && game[2][0] == player);
	}
}
